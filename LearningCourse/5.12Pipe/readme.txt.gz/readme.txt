Ai ở xa về, có việc vào nhà thống lý (1) Pá Tra thường trông thấy có một cô gái ngồi quay sợi gai bên tầng đá trước cửa, cạnh tầu ngựa.

Lúc nào cũng vậy, dù quay sợi, thái cỏ ngựa, dệt vải, chẻ củi hay đi cõng nước dưới khe suối lên, cô ấy cũng cúi mặt, mặt buồn rười rượi. Người ta nói: nhà Pá Tra làm thống lý, ăn của dân nhiều , đồn Tây lại cho muối về bán, giầu lắm, nhà có nhiều nương, nhiều bạc, nhiều thuộc phiện nhất làng. Thế thì con gái nó còn bao giờ phải xem cái khổ mà biết khổ, mà buồn. Nhưng rồi hỏi ra mới rõ cô ấy không phải con gái thống lý: cô ấy là vợ A Sử, con trai thống lý.

Mỵ về làm dâu nhà Pá Tra đã mấy năm. Từ năm nào, không nhớ, cũng không ai nhớ. Những người nghèo ở Hồng Ngài thì vẫn còn kể lại câu chuyện Mỵ về làm người nhà quan thống lý.

(1) Tổ chức cai trị của đế quốc Pháp trước đặt chức thống lý cho bọn chức việc người Mông, cũng như chánh thổng, lý trưởng ở xuôi, phìa ở làng Thái.

Ngày xưa bố Mỵ lấy mẹ Mỵ không đủ tiền cưới, phải đến vay nhà thống lý, bố của thống lý Pá Tra bây giờ. Mỗi năm đem nộp lãi cho nhà chủ nợ một nương ngô. Ðến tận khi hai vợ chồng về già mà cũng chưa xong nợ. Người vợ chết, cũng chưa trả hết nợ.

Cho tới năm ấy Mỵ đã lớn, Mỵ là con gái đầu lòng. Thống lý đến bảo bố Mỵ: - Cho tao đứa con gái này về làm dâu thì tao xoá hết nợ tho.
Ông lão nghĩ năm nào cũng phải trả một nương ngô cho người ta, tiếc ngô, nhưng cũng lại thương con quá. Ông chưa biết nói thế nào thì Mỵ bảo bố rằng:
- Con đã biết cuốc nương làm ngô, con làm nương ngô trả nợ thay cho bố. Bố đừng bán con cho nhà giàu.

Tết năm ấy, tết vui chơi, trai gái đánh pao, đánh quay rồi đêm đêm rủ nhau đi chơi. Những nhà có con gái, bố mẹ không thể ngủ được vì tiếng chó sủa. Suốt đêm, con trai đến nhà người mình yêu, đứng thổi sáo xung quanh vách.
Trai đứng nhắn cả chân vách đầu buồng Mỵ.
Một đêm, khuya Mỵ nghe tiếng gõ vách. Tiếng gõ vách hẹn của người yêu. Mỵ hồi hộp lặng lẽ quờ tay lên, gặp hai ngón tay lách vào khe gỗ. Một ngón đeo nhẫn. Người yêu Mỵ đeo nhẫn ngón tay ấy. Mỵ nhấc tấm vách gỗ. Một bàn tay bắt Mỵ bước ra.
Mỵ vừa bước ra, lập tức có mấy người choàng đến, nhét áo vào miệng Mỵ rồi bịt mắt cõng Mỵ đi.

Sáng hôm sau, Mỵ mới biết mình đang ngồi trong nhà thống lý. Họ nhót Mỵ vào buồng.
Ngoài vách kia, tiếng nhạc sinh tiền cúng ma rập rờn nhảy múa.
A Sử đến nhà bố Mỵ.
A Sử nói:
- Tôi đã đem con gái bố về cúng trình ma nhà tôi. Bây giờ tôi đến cho bố biết. Tiền bạc để cưới, bố tôi bảo đã đưa cả cho bố rồi (1)
Rồi A Sử về. Ông lão nhớ câu nói của thống lý dạo trước; cho con gái về nhà thống lý thì trừ được nợ. Thế là cha mẹ ăn bạc nhà giàu kiếp trước, bây giờ người ta bắt con trừ nự. Không làm thế nào khác được rồi.
Có đến mấy tháng, đêm nào Mỵ cũng khóc.

Một hôm, Mỵ trốn về nhà, hai tròng mắt còn đỏ hoe. Trông thấy bố, Mỵ quì, úp mặt xuống đất, nức nở. Bố Mỵ cũng khóc, đoán biết lòng con gái:
- Mày về chào lậy tao để mày đi chết đấy à? Mày chết nhưng nợ tao vẫn còn quan lại bắt trả nợ. Mày chết rồi, không lấy ai làm nương ngô, trả được nợ, tao thì ốm yếu quá rồi. Không được, con ơi!

(1) người Mông có tục cướp vợ trai gái yêu nhau, bằng lòng nhau (có khi chỉ anh con trai muốn lấy người con gái giữa đêm cùng một số bạn trai khác, đến nhà hiếm). Người con trai giữa đêm cùng một số bạn trai khác, đến nhà người yêu, bí mật "cướp" đi. Hôm sau, người trai trở lại báo tin cho bố người gái ấy là tôi đã cướp được con gái ông làm vợ. Thế là phong tục bắt bố phải nhận lời. Cưới lối "cướp" như thế, người tai mất rất ít tiền.
Thường mùa xuân ăn Tết, con trai hay đi "cướp" vợ. Ðó là phong tục vui, thanh niên rất thích. Bây giờ vẫn thường xảy ra.

Mỵ chỉ bưng mặt khóc. Mỵ ném nắm lá ngón(1) xuống đất. Nắm lá ngón Mỵ đã đi tìm hai trong rừng. Mỵ vẫn giấu trong áo. Thế là Mỵ không đành lòng chết. Mỵ chết thì bố Mỵ còn khổ hơn bao nhiêu lần bây giờ.
Mỵ lại trở lại nhà thống lý.

Lần lần, mấy năm qua, mấy năm sau, bố Mỵ chết. Nhưng Mỵ cũng không còn nghĩ đến Mỵ có thể ăn lá ngón tự tử. ở lâu trong cái khổ, Mỵ cũng quen khổ rồi. Bây giờ Mỵ tưởng mình cũng là con trâu, mình cũng là con ngựa. Con ngựa chỉ biết ăn cỏ, biết đi làm mà thôi.
Mỵ cúi mặt, không nghĩ ngợi nữa, lúc nào cũng nhớ lại những việc giống nhau, mỗi năm một mùa, mỗi tháng lại làm đi làm lại: tết xong lên núi hái thuốc phiện; giữa năm thì giặt đay; đến mùa đi nương bẻ bắp. Và dù đi hái củi, bung ngô, lúc nào cũng gài một bó đay trong cách tay để tước sợi. Bao giờ cũng thế, suốt năm, suốt đời thế. Con ngựa, con trâu làm có lúc, đêm còn được đứng gãi chân, nhai cỏ, đàn bà con gái nhà này vùi vào việc cả đêm cả ngày.

Mỗi ngày Mỵ càng không nói, lùi lũi như con rùa nuôi trong xó cửa. ở
buồng Mỵ nằm kín mít, có một chiếc cửa sổ một lỗ vuông ấy mà trông ra. Ðến bao giờ chết thì thôi.
Trên đầu núi, các nương ngô, nương lúa gặt xong, ngô lúa đã xếp yên các nhà kho.
Trẻ em đi hái bí đỏ, tinh nghịch, đốt những những lều quanh nương để
sưởi lửa. ở Hồng Ngài, người ta thành lệ, cứ ăn tết thì gặt hái vừa đoạn, không kể ngày tháng. ¡n tết thì gặt hái vừa đoạn, không kể ngày tháng. ¡n tết thế cho kịp mưa xuân xuống, đi vỡ nương mới.

(1) một thứ thuốc độc

Hồng Ngài năm ấy ăn tết giữa lúc gió thổi vào cỏ gianh vàng ửng, rét
càng dữ.
Nhưng trong các làng Mông Ðỏ, những chiếc váy hoa đã được phơi ra mỏm đá, xoè như con bướm sặc sỡ. Hoa thuốc phiện nở trắng lại nở màu đỏ hau, đỏ thậm, rồi nở mầu tìm man mát. Ðám trẻ đợi tết, chơi quay, cười ầm trên sân chơi trước nhà.
Ngoài đầu núi, đã có tiếng ai thổi sáo rủ bạn đi chơi. Mỵ nghe tiếng sáo vọng lại, thiết tha bồi hồi.

"Mày có con trai con gái
Mày đi nương
Ta không có con trai con gái
Ta đi tìm người yêu"

Tiếng chó sủa xa xa. Những đêm tình mùa xuân đã tới.
ở mỗi đầu làng đều có một mỏm đất phẳng làm sân chơi chung ngày tết. Trai gái, trẻ con ra sân ấy tụ tập đánh pao, dánh quay, thổi sáo, thổi kèn và nhảy.

Cả nhà thống lý ăn xong bữa cơm tết cúng ma. Xung quanh chiêng đánh ầm ỹ, người ốp đồng vẫn nhảy lên xuống, rung bần bật. Vừa hết bữa cơm tiếp ngay cuộc rượu bên bếp lửa.

Ngày tết, Mỵ cũng uống rượu. Mỵ lén lấy hũ rượu, uống ực từng bát. Rồi say, Mỵ lịm mặt đấy nhìn người nhảy đồng, người hát. Nhưng lòng Mỵ đang sống về ngày trước, tai văng vẳng tiếng sáo gọi bạn đầu làng. Ngày trước Mỵ thổi sáo giỏi. Mùa xuân đến, Mỵ uống rượu bên bếp và thổi sáo. Mỵ uốn chiếc lá trên môi, thổi lá cũng hay như thổi sáo. Có biết bao nhiêu người mê, cứ ngày đêm thổi sáo đi theo Mỵ hết núi này sang núi khác.

Rượu tan lúc nào. Người về, người đi chơi đã vãn cả, Mỵ không biết. Mỵ vẫn ngồi trơ một mình giữa nhà. Mãi sau Mỵ mới đứng dậy. Nhưng Mỵ không bước ra đường. Mỵ từ từ vào buồng.
Chẳng năm nào A Sử cho Mỵ đi chơi hết.
Bấy giờ Mỵ ngồi xuống giường, trông ra cửa sổ lỗ vuông mờ mờ trăng trắng. Từ nay Mỵ thấy phơi phới trở lại, trong lòng đột nhiên vui như những đêm Tết ngày trước. Mỵ trẻ, Mỵ vẫn còn trẻ. Mỵ muốn đi chơi. Bao nhiêu người có chồng cũng đi chơi Tết. Huống chi A Sử với Mỵ không có lòng với nhau mà vẫn phải ở với nhau. Nếu có nắm lá ngón trong tay lúc này, Mỵ sẽ ăn cho chết ngay, chứ không buồn nhớ lại nữa. Nhớ lại, chì thấy nước mặt ứa ra. Mà tiếng sáo gọi bạn vẫn lửng lơ bay ngoài đường.

" Anh ném pao
Em không bắt
Em không yêu
Quả pao rơi rồi..."

A Sử vừa ở đâu về, lại sửa soạn đi chơi. A Sử thay áo mới, khoác thêm vòng bạc vào cổ rồi bịt cái khăn trằng lên đầu. Có khi nó đi mấy ngày mấy đêm. Nó còn đương rình bắt nhiều người con gái nữa về làm vợ. Cũng chẳng bao giờ Mỵ nói.
Bây giờ Mỵ cũng không nói. Mỵ đến góc nhà, lấy ông mỡ, sắn một miếng, bỏ thêm voà đĩa đèn cho sáng.
Trong đầu Mỵ đang rập rờn tiếng sáo. Mỵ muốn đi chơi. Mỵ cũng sắp đi chơi. Mỵ quấn lại tóc. Mỵ với tay lấy cái váy hoa vắt phía trong vách. A Sử sắp bước ra, bỗng quay lại, lấy làm lạ. A Sử nhìn quanh thấy Mỵ rút thêm cái áo.
A Sử hỏi:
- Mày muốn đi chơi à?
Mỵ không nói. A Sử cũng không hỏi thêm. A Sử bước lại, nắm Mỵ, lấy thắt lưng trói tay Mỵ. Nó xách cả một thúng sợi đay ra trới đứng Mỵ vào cột nhà. Tóc Mỹ xoã xuống. A Sử quấn luôn tóc lên cột. Mỵ không cúi, không nghiêng được đầu nữa. Trói xong. A Sử thắt cái thắt lưng xanh ra ngoài áo rồi phẩy tay tắt đèn, đi ra khép cửa buồng lại.

Trong bóng tối, Mỵ đứng im như không biết mình đang bị trói. Hơi rượu còn nồng nàn. Mỵ vẫn nghe thấy tiếng sáo đưa Mỵ đi theo những cuộc chơi. "Em không yêu, quả pao rơi rồi. Em yêu người nào, em bắt pao nào!" Mỵ vùng bước đi. Nhưng chân đau không cựa được. Mỵ không nghe tiếng sáo nữa. Chỉ còn nghe tiếng chân ngựa đạp vào vách. Ngựa vẫn đứng yên, gãi chân, nhai cỏ. Mỵ thổn thức nghĩ mình không bằng con ngựa.

Chó sủa xa xa. Chừng đã khuya. Lúc này, lúc trai đang đến gò vách làm hiệu, rủ người yêu dỡ vách ra rừng chơi. Mỵ nín khóc, Mỵ lại bồi hồi.
Cả đêm Mỵ phải trói đứng như thế. Lúc thì khắp người bị dây trói thít lại, đau nhức. Lúc lại tràn trề tha thiết nhớ. Hơi rượu toả. Tiếng sáo. Tiếng chó sửa xa xa. Mỵ lúc mê, lúc tình. Cho tới khi trời tang tảng rồi không biết sáng từ bao giờ.
Mỵ bàng hoàng tỉnh. Buổi sáng âm âm trong cái nhà gỗ rộng. Vách bên cũng im ắng. Không nghe tiếng lửa réo trong lò nấu lợn. Không một tiếng động. Không biết bên buông quanh đấy, các chị vợ anh, vợ chú của A Sử có còn ở nhà, không biết tất cả những người đàn bà khốn khổ sa vào nhà quan đã được đi chơi hay cũng đang phải trói như Mỵ. Mỵ không thể biết.
Ðời người đàn bà lấy chồng nhà giàu ở Hồng Ngài, một đời người chỉ biết đi theo đuổi con ngựa của chồng. Mỵ chợt nhớ lại câu chuyện người ta vẫn kể: đời trước, ở nhà thống lý Pá Tra có người trói vợ trong nhà ba ngày rồi đi chơi, khi về nhìn đến, vợ chết rồi. Mỵ sợ quá, Mỵ cựa quậy. Xem mình còn sống hay chết. Cổ tay, đầu, bắp chân bị dây chói xiết lại, đâu đứt từng mảnh thịt.

Có tiếng xôn xao phía ngoài. Rồi một đám đông vào nhà. Thống lý Pá Tra xuống ngựa vứt cương cho "thị sống" (một chức việc đi hầu thống lý như người làm mõ thời trước) dắt ngựa vào tàu. Nghe như bọn họ khiêng theo con lợn, hoặc một người phải trói, vừa vứt huỵnh xuống đất, cứ thở phò phò. A Sử chệnh choạng vào buồng. áo rách toạch một mảnh vai. Cái khăn xéo trắng loang lổ máu, xụp xuống quanh trán. A Sử nằm lăn ra giường. Thống lý Pá Tra bước vào. Theo sau thống lý, một lũ "thống quán" (Một chức việc như phó lý) "xéo phải" (như trưởng thôn) và bọn thị sống vẫn thường ra vào hầu hạ, ăn thịt uống rượu, hút thuốc phiện nhà thống lý.
Có người bấy giờ mới nhìn thấy Mỵ phải trói đứng trong cột. Nhưng cũng không ai để ý. Họ xúm lại quanh giường A Sử.
Pá Tra, tay vẫn cầm cái roi ngựa, lại từ từ đi ra. Mỵ nhắm mặt lại, không dám nhìn. Mỵ chỉ nghe hình như có tiếng ông thống lý gọi người ra ngoài. Mỵ hé nhìn ra, thấy chị dâu bước tới. Người chị dâu ấy chưa già, nhưng cái lưng quanh năm phải đeo thồ nặng quá, đã còng rạp xuống. Người chị dâu đến cởi chói cho Mỵ. Sợi dây gai bắp chân vừa lỏng ra, Mỵ ngã sụp xuống. Chị dâu khẽ nói vào tai Mỵ:
- Mỵ! đi hái thuốc cho chồng mày.
Mỵ quên cả đau đứng lên. Nhưng không nhích chân lên được. Mỵ phải ôm vai chị dâu. hai người khổ sở dìu nhau bước ra. Vào rừng tìm lá thuốc, Mỵ nghe nói lại, mới biết A Sử đi chơi bị đánh vỡ đầu.
Nửa đêm qua, A Sử vào làng tìm đến đám tiếng sáo, tiếng khèn. Nhiều
chàng trai làng ấy vào các làng khác, chơi quay, thổi sáo suốt ngày, chập tối vừa tan xong chầu rượu trong nhà, bây giờ vẫn còn chưa chịu tan về. Lúc A Sử và chúng bạn kéo đến, không còn ai chơi trong nhà. Nhưng người ra người vào còn dập dìu quanh ngõ.
A Sử đứng ngoài, tức lắm. Nó bàn với lũ khác, doạ đánh bọn trai lạ bám quanh nhà, khiến bọn A Sử bị vương không thể vào được.
Bọn A Sử ném vào vách. Ông bố trong nhà ra chửi. Vẫn ném. Ông lão vào trong cửa, bắn ra hai phát súng. Thế là tan những đám hẹn.
Nhưng cũng chưa người trai nào vội về. Họ tản vào các nhà quen trong xóm. Ðợi sáng mai lại lên sân đánh pao với con gái trong xóm.
Bọn A Sử cũng không chịu để cánh kia yên. Sáng sớm, khi họ vừa ra đầu ngõ, bọn A Sử đã kéo đến gây sự. A Sử đi trước, nạm vòng bạc rủ xuống tua chỉ xanh đỏ, chỉ riêng con cái nhà quan trong làng mới được đeo. A Sử hùng hổ bước ra. Bọn kia đứng dồn cả lại, xôn xao.
- Lũ phá đám ta hôm qua đây rồi.
- A Phủ đâu! A phủ đánh chết nó đi!
Một người to lớn chạy vụt ra, vung tay ném con quay thẳng vào mặt A Sử. Con quay gỗ ngát lăng vào giữa mặt. Nó vừa kịp bưng tay lên, A Phủ đã xộc tới, nắm vòng cổ, kéo dập đầu xuống, xé vai áo, đánh tới tấp. Người làng nghe tiếng hò hét đổ ra. Bọn trai làng lạ tản hết lên rừng. Mấy người đuổi đón đầu A Phủ.

A Phủ bị bắt sống, trói gô chân tay lại. Vừa lúc thồng s lý Pá Tra tới. Chúng nó xọc ngang cái gậy, khiêng A Phủ mang về ném xuống giữa nhà thống lý.
Mỵ đi hái được lá thuốc về, thấy trong nhà càng đông hơn lúc nãy. Ngoài sân, dưới gốc đào lại buộc thêm mấy con ngựa lạ.
Mỵ đi cửa sau vào, lé mặt nhìn thấy một người to lớn quỳ trong góc nhà. Mỵ đoán đấy là A Phủ.
Bọn chức việc cả vùng Hồng Ngài đến nhà thống lý dự đám kiện.
Các lý dịch, quan làng thống quán, xéo phải, đội mũ quấn khăn, xách gậy, cưỡi ngựa kéo đến xử kiện và ăn cỗ.
Trong nhà thống lý đã bày ra năm bàn đèn. Khói thuốc phiện tuôn ra các lỗ cửa sổ tun hút xanh như khói bếp. Cả những người chức việc bên làng A Phủ cũng tới. Chỉ bọn trai làng ấy phải ngồi khoanh tay cạnh A Phủ, vì họ bị gọi sang hầu kiện. Bọn chức việc nằm dài cả trên khay đèn.
Suốt từ trưa cho tới hết đêm, mấy chục người hút. Trên nhất là thống lý Pá Tra. Thống lý hút xong một đợt năm điếu, đến người khác, lại người khác, cứ thế lần lượt xuống tới bọn đi gọi người về dự kiện.
Chỉ có đàn bà ngồi trong buồng và đi bên ngoài dòm ngó đám xử kiện và A Phủ quỳ chịu tội ở xó nhà, không được dự tiệc hút ấy.
Một loạt người vừa hút xong, Pa Tra ngồi dậy, vuốt ngược cái đầu trọc dài, kéo đuôi tóc ra đằng trước, cất gọng lè nhè gọi:
- Thằng A Phủ ra đây.
A Phủ ra quỳ giữa nhà. Lập tức, bọn trai làng xô đến, trước nhất, chắp tay lạy lia lịa lên thống lý rồi quay lại đánh A Phủ.
A Phủ quỳ chịu đòn, chỉ im như cái tượng đá...
Cứ mỗi đợt bọn chức việc hút thuốc phiện xong, A Phủ lại phải ra quỳ giữa nhà, lại bị người xô đến đánh. Mặt A Phủ sưng lên, môi và đuôi mắt dập chảy máu. Người đánh, kể, chửi , lại hút. Khói thuốc phiện ngào ngạt tuôn qua các lỗ cửa sổ. Rồi Pá Tra lại ngóc cổ lên, vuốt tóc, gọi A Phủ... Cứ như thế, suốt chiều, suốt đêm, càng hút, càng tỉnh, càng đánh, càng chửi, càng hút.

Trong buồng bên cạnh, Mỵ cũng thức suốt đêm, im lặng ngồi xoa thuốc dấu cho A Sử. Lúc nào Mỵ mỏi quá, cựa mình, những chỗ lằn trói trong người lại đau ê ẩm. Mỵ lại gục đầu nằm thiếp. A Sử đạp chân vào mặt Mỵ. Mỵ choàng thức, lại nhặt nắm lá thuốc xoa đều đều trên lưng chồng.
Ngoài nhà vẫn rên lên từng cơn kéo thuốc phiện, như những con mọt nghiến ghỗ kéo dài, giữa tiếng người khóc, tiếng người kể lào xào, và tiếng đấm đánh huỳnh huỵch.
Sáng hôm sau, đám kiện đã xong. Mấy người chẳng biết từ bao giờ, ngủ
ngáy ngay bên khay đèn. Bọn xéo phải đang bắc cái chảo đồng và xách ấm nước ra nấu thêm lạng thuốc để hút ban ngày cho các quan làng thật tình, các quan làng còn một tiệc ăn cỗ nữa.
Thống lý mở tráp, lấy ra một trăm đồng bạc hoa xoè bày lên mặt tráp, rồi nói:
- Thằng A Phủ kia, mày đành người thì làng xử mày phải nộp vạ cho người phải mày đánh là hai mươi đồng, nộp cho thống quán năm đông, mỗi xéo phải hai đồng, mỗi người đi gọi các quan làng về hầu kiện năm hào. Mày phải mất tiền mời các quan hút thuốc từ hôm qua tới nay. Lại mất con lợn hai mươi cân, chốc nữa mổ để các quan làng ăn vạ mày. A Phủ, mày đánh con quan làng, đáng lẽ làng xử mày tội chết, nhưng làng tha cho mày được sống mà nộp vạ. Cả tiền phạt, tiền thuốc, tiền lợn, mày phải chịu một trăm bạc trắng. Mày không có trăm bạc thì tao cho mày vay để mày ở nợ. Bao giờ có tiền trả thì tao cho mày về, chưa có tiền trả thì tao bắt mày làm con trâu cho nhà tao. Ðời mày, đời con, đời cháu mày tao cũng bắt thế, bao giờ hết nợ tao mới thôi. A Phủ! Lại đây nhận tiền quan cho vay.

A Phủ lê hai cái đầu gối sưng bạnh lên như mặt hổ phù. A Phủ cúi sờ lên đồng bạc trên tráp, trong khi Pá Tra đốt hương, lầm rầm khấn gọi mà về nhận mặt người vay nợ. Pá Tra khấn xong, A Phủ cũng nhặt xong bạc, nhưng chỉ nhặt làm phép lên như thế rồi lại để ngay xuống mặt tráp. Rồi Pá Tra lại trút cả bạc vào trong tráp.
Con lợn vừa bắt về cho A Phủ thết làng ăn vạ đã kêu eng éc ngoài sân. Ðếm tiền rồi, A Phủ không phải quỳ, phải đánh nữa.
A Phủ đứng lên cầm con dao, chân đau bước tập tễnh, cùng với trai làng ra chọc tiết làm thịt lợn hầu làng.
Trong nhà, thuốc phiện vẫn hút rào rào.

Thế là từ đấy A Phủ phải ở trừ nợ cho nhà quan thống lý. Ðốt rừng, cày nương, cuốc nương, săn bò tót, bẫy hổ, chăn bò chăn ngựa, quanh năm một thân một mình rong ruổi ngoài gò rừng. A Phủ đương tuổi sức lực. Ði làm hay đi săn cái gì cũng phăng phăng. Không còn có lúc nào trở về làng bên. Nhưng A Phủ cũng chẳng muốn trở về làm gì bên ấy.
A Phủ cũng không phải người bên ấy. Bố mẹ đẻ A Phủ ở Hắng Bìa. Năm xưa, làng Hắn Bìa phải một trận bệnh đậu mùa, nhiều trẻ con, cả người lớn chết, có nơi chết cả nhà. Còn sót lại có một mình A Phủ. Có người làng đói bắt A Phủ đem xuống bán đổi lấy thóc của người Thái dưới cánh đồng. A Phủ mới mười một tuổi, nhưng A Phủ gan bướng, không chịu ở cánh đồng thấp.
A Phủ trốn lên núi, lưu lạc đến Hồng Ngài. Ði làm cho nhà người, lần nữa mùa này sang mùa khác. Chẳng bao lâu A Phủ đã lớn, biết đúc lưỡi cày, biết đục cuốc, lại cày giỏi và đi săn bò tót rất bạo.
A Phủ khoẻ, chạy nhanh như ngựa. Con gái trong làng nhiều cô mê. Nhiều người nói: "Ðứa nào được A Phủ cũng bằng được con trâu tốt trong nhà.
Chẳng mấy lúc mà giàu". Người ta ao ước đùa thế thôi chứ phép rượu cũng chẳng to hơn phép làng, còn tục lệ cưới xin, mà A Phủ không có bố mẹ, không có ruộng, không có bạc, A Phủ không thể lấy nổi vợ.
Tuy nhiên, đang tuổi chơi, trong ngày tết đến, A Phủ chẳng có quần áo mới như nhiều trai khác, A Phủ chỉ có độc một chiếc vòng bằng sợi dây đồng vía lằn trên cổ. A Phủ cứ cùng trai làng đem sáo, khèn, đem con quay và quả pao, quả yến đi tìm người yêu ở các làng trong vùng.
Vì thế sinh sự đánh nhau ở Hồng Ngài.

Một năm kia, phải khi đang đốt rừng. Hổ gấu từng đàn ra phá nương, bắt mất nhiều bò ngựa. Nhà thống lý lúc nào cũng đầy ngựa trong tàu trước cửa, đầy lưng bò đứng chen chân trong cột cửa, và dê, chó, lợn nằm quanh nhà. Ngày nào cũng lũ lượt hàng mấy chục con đi nương ăn. Bây giờ gặp khi rừng đói, mỗi lần bò ngựa đi nương, A Phủ phải ở lại trong rừng.
A Phủ ở lều hàng tháng ngoài nương. Ðêm đến, dồn bò ngựa về nằm chầu nhau ngủ quanh lều.
Mấy ngày A Phủ mê mải đi bẫy dím, không đếm được ngựa. Hôm ấy vào rừng thấy vết chân hổ. A Phủ vội phóng ngựa chạy vờn quanh đàn, dồn chúng quấn lại để đếm. A Phủ đếm lại mấy lần. Thiếu một con bò. A Phủ nhào vào rừng, lần theo lốt chân hổ, tìm được con bò đã bị hổ ăn thịt, chỉ còn lại một nửa mình nằm ngay dưới cây thông cụt.
A Phủ nhặt mấy miếng thịt rơi quanh đấy rồi vác nốt nửa con bò về. Nghĩ bụng: "Con hổ này to lắm. Hay còn ngưởi thấy mùi hôi quanh đây. Ta về lấy súng đi tìm, thế nào cũng bắn được".
Về đến nhà, A Phủ lẳng vai ném nửa con bò xuống gốc đào trước cửa. Pá Tra bước ra hỏi:
- Mất mấy con bò?
A Phủ trả lời tự nhiên:
- Tôi về lấy súng. Thế nào cũng bắn được. Con hổ này to lắm.
- Pá Tra hất tay, nói:
- Quân ăn cướp mất bò tao. A Sử đâu! Ðem súng đi lấy con hổ về.
Rồi Pá Tra quay lại, bảo A Phủ:
- Mày ra ngoài kia, lấy vào đây một cái cọc, một cuộn dây mây. Tao trói mày chỗ kia. Bao giờ chúng nó bắn được con hổ về thì mày khỏi phải chết. Nếu không bắn được con hổ về thì tao cho mày đứng chết ở đấy.
A Phủ cãi:
- Tôi được con hổ ấy còn nhiều tiền hơn con bò.
Pá Tra cười:
- Lấy cọc dây mây vào đây!ư
Không nói nữa, như con trâu đã đóng lên tròng. A Phủ lẳng lặng ra vác chiếc cọc gỗ rồi lấy cuộn dây mây trên gác bếp xuống. Tự tay A Phủ đóng cọc xuống bên cột, Pá Tra đẩy A Phủ vào chân cột, hai tay bắt ôm quặt lên. Rồi dây mây cuốn từ chân lên vai, chỉ còn cổ và đâu lúc lắc được.
Ðàn bà trong nhà, mỗi khi đi qua đều cúi mặt. Không một ai dám hỏi. Cũng không một ai dám nhìn ngang mặt.
Ðến đêm, A Phủ cúi xuống, nhay đứt hai vòng mây, nhích dãn dây trói một bên ta. Nhưng trời cũng vừa sáng. Pá Tra quảng thêm một vòng tròng lọng vào cổ. Thế là A Phủ không cúi, không còn lắc được nữa.
A Sử và lĩnh dõng của thống lý đi đuổi, mấy ngày không lùng bắt được con hổ. Thì cũng mấy ngày A Phủ phải trói đứng góc nhà. Ðằng kia, bếp lò bung ngô cao ngang đầu người vẫn hừng hực đỏ rực. Môi hôm hai buổi, người ta ra người vào ăn uống tấp nập. A Phủ đứng nhắm mắt, cho tới đêm khuya.

Những đêm mùa đông trên núi cao dài và buồn. Nếu không có bếp lửa sưởi kia thì Mỵ cũng đến chết héo. Mỗi đêm, Mỵ dậy ra thổi lửa hơ tay, hơ lưng, không biết bao nhiêu lần.
Thường khi đến gà gáy, Mỵ dậy ra bếp sưởi một lúc thật lâu, các chị em trong nhà mới bắt đầu ra dóm lò bung ngô, nấu cháo lợn.
Mỗi đêm, nghe tiếng phù phù thổi bếp, a Phủ lại mở mắt. Ngọn lửa bùng lên, cùng lúc ấy Mỵ cũng nhìn sang, thấy mắt A Phủ trừng trừng. Mới biết nó còn sống. Mấy đêm nay như thế.
Nhưng Mỵ vẫn thản nhiên thổi lửa, hơ tay. nếu A Phủ là cái xác chết đứng chết đấy, cũng thế thôi. Mỵ vẫn trở dậy, vẫn sưởi, Mỵ chỉ biết, chỉ còn ở với ngọn lửa. Có đêm A Sử chợt về thấy Mỵ ngồi đấy, A Sử ngứa tay đánh Mỵ ngã xuống cửa bếp. Nhưng đêm sau Mỵ vẫn ra sưởi như đêm trước.
Lúc ấy đã khuya. Trong nhà ngủ yên. Mỵ trở dậy thổi lửa, ngọn lửa bập bùng sáng lên. Mỵ trông sang thấy hai mắt A Phủ cũng vừa mở. Dòng nước mắt lấp lánh bò xuống hai hóm má đã xám đen. Thấy tình cảnh thế, Mỵ chợt nhớ đêm năm trước, A Sử trói Mỵ, Mỵ cũng phải trói đứng thế kia. Nước mắt chảy xuống miệng, xuống cổ, không biết lau đi được. Trời ơi nó bắt trói đứng người ta đến chết. Nó bắt mình chết cũng thôi. Nó đã bắt trói đến chết người đàn bà ngày trước ở cái nhà này. Chúng nó thật độc ác. Chỉ đêm mai là người ta chết, chết đau, chết đối, chết rét, phải chết. Ta là thân phận đàn bà, nó đã bắt về trình ma rồi, chỉ còn biết đợi ngày rũ xương ở đây thôi... Người kia việc gì mà phải chết. A Phủ ... Mỵ phảng phất nghĩ như vậy.

Ðám than đã vạc hẳn lửa. Mỵ không thổi cũng không đứng lên. Mỵ nhớ lại đời mình. Mỵ tưởng tượng như có thể một lúc nào, biết đâu A Phủ chẳng trốn được rồi, lúc đó bố con thống lý sẽ đổ là Mỵ đã cởi trói cho nó, Mỵ liền phải trói thay vào đấy. Mỵ chết trên cái cọc ấy. Nghĩ thế, nhưng làm sao Mỵ cũng không thấy sợ...
Trong nhà tối bưng, Mỵ rón rén bước lại, A Phủ vẫn nhắm mắt. Nhưng Mỵ tưởng như A Phủ biết có người bước lại... Mỵ rút con dao nhỏ cắt lúa, cắt nút dây mây. A Phủ thở phè từng hơi như rắn thở, không biết mê hay tỉnh. Lần lần, đến lúc gỡ được hết dây trói ở người A Phủ thì Mỵ cũng hốt
hoảng. Mỵ chỉ thì thào được một tiếng "Ði đi..." rồi Mỵ nghẹn lại. A Phủ khuỵu xuống không bước nổi.
Nhưng trước cái chết có thể đến nơi ngay, A Phủ lại quật sức vung lên, chạy.
Mỵ đứng lặng trong bóng tối.
Trời tối lắm. Mỵ vẫn băng đi. Mỵ đuổi kịp A Phủ, đã lăn, chạy xuống tới lưng dốc.
Mỵ thở trong hơi gió thốc lạnh buốt:
- A Phủ cho...
A Phủ chưa kịp nói, Mỵ lại vừa thở vừa nói:
- ở đây chết nất,
A Phủ chợt hiểu.
Hai người đỡ nhau lao xuống dốc núi.

Hai người đi ròng rã hơn một tháng. Họ truyền trên những triền núi cao ngất, lốm đốm nhà, thấp thoáng ruộng, đất đỏ, suối trắng tinh, trông thấy trước mặt mà đi mấy ngày chưa tới. Từ Hồng Ngài xuống qua vùng ruộng ở Mường Quài của người thái, từ Nậm Cất sang Chống Chia, từ Chống Chia qua dốc Lùng Chùng Phủng lại trở về bờ sông Ðà phía giữa châu Phù Yên sang châu Mai Sơn, chỗ đầu mối giao thông của ngoài vùng tự do vào khu du kích của các dân tộc Thái, Dao, Mèo bên kia sống. Rồi họ về trong những làng Mông Ðỏ hẻo lánh vùng Phìa Sa. Xa lắm rồi, thống lý không đuổi được nữa... họ nghĩ thế.

Ròng rã, ăn rau rừng, củ nâu, mộc nhĩ, vừa hết mùa mưa, tới Phìn Sa.
Hai người tới Phìn Sa, ở đấy không ai biết đấy là A Phủ, người ở nợ nhà thống lý. Người ta ngỡ đấy là hai vợ chồng trong một nhà đông anh em ở bên kia dốc Lùng Chùng Phủng, nương vỡ được ít mà miệng ăn thì nhiều, anh em, vợ chồng phải chia ra, đem nhau đi tìm ăn nơi khác.
Hai người nhận là vợ chồng. Mà thật thì A Phủ và Mỵ đã thành vợ chồng.